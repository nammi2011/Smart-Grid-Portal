/* V6_ErrorEnvelope.groovy — DUPLICATE_OK / SKIPPED_STALE return 200 (not errors);
 * DNC_BAD_EVENT returns 400 (no redelivery: contract breach goes to producer);
 * anything unexpected returns 500 for redelivery. */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) {
    def code = (message.getProperty('cpc.errorCode') ?: 'INTERNAL') as String
    def http = (message.getProperty('cpc.httpCode') ?: '500') as String
    def replay = message.getProperty('cpc.replayBody') as String
    def corr = (message.getProperty('cpc.correlationId') ?: '') as String
    message.setHeader('Content-Type','application/json')
    message.setHeader('X-Correlation-ID', corr)
    message.setHeader('CamelHttpResponseCode', http)
    if (replay) { message.setBody(replay); return message }
    message.setBody(JsonOutput.toJson([error:[code:code, correlationId:corr,
        retryable: http.startsWith('5')]]))
    if (http.startsWith('5')) message.setHeader('Retry-After','120')
    return message
}
