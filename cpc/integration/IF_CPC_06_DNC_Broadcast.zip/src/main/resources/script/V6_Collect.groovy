/* V6_Collect.groovy — records the previous target outcome (no-throw HTTP adapters put
 * the status in CamelHttpResponseCode) and prepares the next target request.
 * Stage is tracked in property cpc_stage: '' -> after dialer? no: this script is used
 * three times; it infers position from which flags are still unprocessed. */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*

def Message processData(Message message) {
    def slurper = new JsonSlurper()
    def receipts = slurper.parseText((message.getProperty('cpc_receipts') ?: '[]') as String)
    def d = slurper.parseText(message.getProperty('cpc_event') as String)
    def action = message.getProperty('cpc_action') as String
    def evtId = message.getProperty('cpc_evtId') as String
    def stage = (message.getProperty('cpc_stage') ?: 'START') as String

    def record = { target ->
        def rc = (message.getHeaders().get('CamelHttpResponseCode') ?: '0') as String
        receipts << [target: target, action: action,
                     status: (rc.startsWith('2') ? 'CONFIRMED' : 'FAILED'), httpCode: rc]
    }

    if (stage == 'START') {
        // arriving after dialer RR (or straight from gateway skip)
        if ((message.getProperty('cpc_dialer') as String) == 'true') record('DIALER')
        // prepare campaign request (spec 4.2)
        def consent = [:]
        def t = d.preferenceType as String
        if (t == 'DNC') consent.voice = (d.value == 'IN' ? 'DENIED' : 'ALLOWED')
        if (t == 'DNM') consent.print = (d.value == 'IN' ? 'DENIED' : 'ALLOWED')
        if (t == 'THIRD_PARTY') consent.dataSharing = (d.value == 'IN' ? 'DENIED' : 'ALLOWED')
        message.setBody(JsonOutput.toJson([contactKey: d.businessPartner, channelConsent: consent,
            consentTimestamp: d.changedAt ?: '', eventId: evtId]))
        message.setProperty('cpc_stage', 'AFTER_CAMPAIGN')
    } else if (stage == 'AFTER_CAMPAIGN') {
        record('CAMPAIGN')
        // prepare print request (spec 4.3) — only used when cpc_print = true
        message.setBody(JsonOutput.toJson([addressRef: d.businessPartner, action: action, externalRef: evtId]))
        message.setProperty('cpc_stage', 'AFTER_PRINT')
    } else {
        if ((message.getProperty('cpc_print') as String) == 'true') record('PRINT')
        // prepare receipt write-back (spec section 6)
        message.setBody(JsonOutput.toJson([businessPartner: d.businessPartner,
            preferenceUUID: d.preferenceUUID ?: null, action: 'DNC_BROADCAST',
            sequenceNo: d.sequenceNo, receipts: receipts,
            correlationId: message.getProperty('cpc.correlationId')]))
        message.setProperty('cpc_stage', 'DONE')
    }
    message.setProperty('cpc_receipts', JsonOutput.toJson(receipts))
    message.setHeader('Content-Type','application/json')
    return message
}
