/* V6_Respond.groovy — after the audit write-back RR: mark dedup + sequence on full
 * success; any FAILED target -> HTTP 500 so Event Mesh redelivers (targets are
 * idempotent on externalRef = event id). Spec sections 6, 8. */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*

def Message processData(Message message) {
    def receipts = new JsonSlurper().parseText((message.getProperty('cpc_receipts') ?: '[]') as String)
    def logRc = (message.getHeaders().get('CamelHttpResponseCode') ?: '0') as String
    def evtId = message.getProperty('cpc_evtId') as String
    def d = new JsonSlurper().parseText(message.getProperty('cpc_event') as String)
    def allOk = receipts.every { it.status == 'CONFIRMED' } && logRc.startsWith('2')

    if (allOk) {
        try {
            def ds = com.sap.it.api.ITApiFactory.getService(com.sap.it.api.asdk.datastore.DataStoreService.class, null)
            if (ds != null) {
                def put = { store, id, val, days ->
                    def b = new com.sap.it.api.asdk.datastore.DataBean(); b.setDataAsArray(val.getBytes('UTF-8'))
                    def c = new com.sap.it.api.asdk.datastore.DataConfig(); c.setStoreName(store); c.setId(id)
                    c.setOverwrite(true); c.setExpires(days as Long); ds.put(b, c) }
                put('CPC_DNC_EVT', evtId, 'done', 7L)
                put('CPC_DNC_SEQ', d.businessPartner as String, String.valueOf(d.sequenceNo), 3650L)
            }
        } catch (Exception ignore) {}
    }
    message.setBody(JsonOutput.toJson([status: allOk ? 'done' : 'partial',
        eventId: evtId, auditWriteBack: logRc, receipts: receipts]))
    message.setHeader('Content-Type','application/json')
    message.setHeader('X-Correlation-ID', message.getProperty('cpc.correlationId') ?: '')
    message.setHeader('CamelHttpResponseCode', allOk ? '200' : '500')  // 500 => webhook redelivery
    if (!allOk) message.setHeader('Retry-After', '120')
    return message
}
