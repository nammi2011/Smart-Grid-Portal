/* V6_ValidateEvent.groovy — IF_CPC_06: envelope validation, dedup, sequence guard,
 * target plan, dialer request prep. Spec sections 3-5. */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*

def Message processData(Message message) {
    def fail = { code, http, body=null ->
        message.setProperty('cpc.errorCode', code)
        message.setProperty('cpc.httpCode', String.valueOf(http))
        if (body) message.setProperty('cpc.replayBody', JsonOutput.toJson(body))
        throw new IllegalStateException('CPC:' + code) }

    def evt
    try { evt = new JsonSlurper().parseText(message.getBody(String) ?: '') }
    catch (Exception e) { fail('DNC_BAD_EVENT', 400) }
    def okTypes = ['zcpc.DncChanged.v1','zcpc.DnmChanged.v1','zcpc.ThirdPartyChanged.v1']
    if (!(evt instanceof Map) || !okTypes.contains(evt.type as String) || !(evt.data instanceof Map))
        fail('DNC_BAD_EVENT', 400)
    def d = evt.data
    if (!d.businessPartner || !d.preferenceType || !d.value || d.sequenceNo == null)
        fail('DNC_BAD_EVENT', 400)

    def corr = (d.correlationId ?: message.getHeaders().get('X-Correlation-ID') ?: UUID.randomUUID().toString()) as String
    message.setHeader('X-Correlation-ID', corr)
    message.setProperty('cpc.correlationId', corr)
    def evtId = (evt.id ?: UUID.randomUUID().toString()) as String
    message.setProperty('cpc_evtId', evtId)
    message.setProperty('cpc_event', JsonOutput.toJson(d))

    // dedup (only successful events are stored - see V6_Respond)
    try {
        def ds = com.sap.it.api.ITApiFactory.getService(com.sap.it.api.asdk.datastore.DataStoreService.class, null)
        if (ds != null) {
            if (ds.get('CPC_DNC_EVT', evtId) != null)
                fail('DUPLICATE_OK', 200, [status:'duplicate', eventId:evtId])
            def seqStored = ds.get('CPC_DNC_SEQ', d.businessPartner as String)
            if (seqStored != null) {
                long last = new String(seqStored.getDataAsArray(),'UTF-8').toLong()
                if ((d.sequenceNo as Long) <= last)
                    fail('SKIPPED_STALE', 200, [status:'skipped_stale', eventId:evtId, lastSequence:last])
            }
        }
    } catch (IllegalStateException e) { throw e } catch (Exception ignore) {}

    // target plan
    def type = d.preferenceType as String
    message.setProperty('cpc_dialer', type == 'DNC' ? 'true' : 'false')
    message.setProperty('cpc_print',  type == 'DNM' ? 'true' : 'false')
    message.setProperty('cpc_receipts', '[]')

    // dialer request (spec 4.1)
    def action = (d.value == 'IN') ? 'ADD' : 'REMOVE'
    message.setProperty('cpc_action', action)
    message.setBody(JsonOutput.toJson([customerRef: (d.businessPartner as String).replaceFirst(/^0+/,''),
        action: action, listType: 'DO_NOT_CALL', effectiveDate: d.validFrom ?: '',
        externalRef: evtId, reason: 'CUSTOMER_PREFERENCE']))
    message.setHeader('Content-Type','application/json')
    return message
}
