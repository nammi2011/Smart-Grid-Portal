/* ErrorEnvelope.groovy — IF_CPC_02 exception subprocess (spec section 7)
 * Builds the standard customer-safe error envelope from cpc.* properties (fail-fast
 * validation path) or from the caught exception / backend response (S/4 call path).
 * DUPLICATE_REPLAY is the idempotent-replay special case: returns 200 + stored body.
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) {
    def corr = (message.getProperty('cpc.correlationId') ?: message.getHeaders().get('X-Correlation-ID') ?: '') as String
    def code = message.getProperty('cpc.errorCode') as String
    def http = message.getProperty('cpc.httpCode') as String

    // Idempotent replay: not an error at all.
    if (code == 'DUPLICATE_REPLAY') {
        message.setBody(message.getProperty('cpc.replayBody') ?: '{"status":"success","replayed":true}')
        message.setHeader('Content-Type', 'application/json')
        message.setHeader('X-Correlation-ID', corr)
        message.setHeader('CamelHttpResponseCode', '200')
        return message
    }

    def msg = message.getProperty('cpc.errorMessage') as String
    def details = message.getProperty('cpc.errorDetails') as String

    if (!code) {
        // Exception from the S/4 call (or unexpected): classify from the adapter.
        def ex = message.getProperty('CamelExceptionCaught')
        def backendCode = null
        try {
            if (ex != null && ex.metaClass.respondsTo(ex, 'getStatusCode')) backendCode = ex.getStatusCode()
        } catch (Exception ignore) {}
        def exText = (ex != null ? String.valueOf(ex.getMessage()) : '')
        if (backendCode in [401, 403]) { code = 'FOREIGN_PARTNER'; http = '403'; msg = 'You are not authorized for this account.' }
        else if (backendCode == 404)   { code = 'RECORD_NOT_FOUND'; http = '404'; msg = 'The record was not found. Please refresh and try again.' }
        else if (backendCode == 409)   { code = 'CONCURRENT_CHANGE'; http = '409'; msg = 'This preference was changed by someone else. Please refresh and reapply your change.' }
        else if (backendCode == 422)   { code = 'BUSINESS_RULE'; http = '422'; msg = "We couldn't save your preferences. One of the changes is not allowed." ; details = JsonOutput.toJson([[message: exText.take(200)]]) }
        else if (backendCode != null && backendCode >= 500) { code = 'BACKEND_ERROR'; http = '502'; msg = 'We are having trouble saving right now. Please try again in a moment.' }
        else { code = 'BACKEND_UNAVAILABLE'; http = '503'; msg = 'We are having trouble saving right now. Please try again in a moment.' }
    }

    def retryable = (http in ['502', '503'])
    def envelope = [error: [code: code, message: msg, correlationId: corr, retryable: retryable]]
    if (details) { try { envelope.error.details = new groovy.json.JsonSlurper().parseText(details) } catch (Exception ignore) {} }

    message.setBody(JsonOutput.toJson(envelope))
    message.setHeader('Content-Type', 'application/json')
    message.setHeader('X-Correlation-ID', corr)
    message.setHeader('CamelHttpResponseCode', http ?: '500')
    if (retryable) message.setHeader('Retry-After', '30')
    return message
}
