/* ValidateAndGuard.groovy — IF_CPC_02 steps B/C/D/E (spec sections 2, 4, 5)
 * - JSON schema/enum/semantic validation (fail fast, S/4 never called on bad input)
 * - Identity guard: changedBy/changedByRole/source/onBehalfOf/caseId come from the
 *   verified headers injected by API Management (X-Verified-User / X-Verified-Role /
 *   X-Verified-Client) — NEVER from the client payload.
 * - Correlation + requestId handling; optional duplicate detection via Data Store.
 * Errors: throws after setting cpc.* properties; ErrorEnvelope.groovy builds the
 * customer-safe envelope (spec section 7).
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def props = [:]
    def fail = { String code, String msg, int http, details = null ->
        message.setProperty('cpc.errorCode', code)
        message.setProperty('cpc.errorMessage', msg)
        message.setProperty('cpc.httpCode', String.valueOf(http))
        if (details != null) message.setProperty('cpc.errorDetails', JsonOutput.toJson(details))
        throw new IllegalStateException("CPC:" + code)
    }

    // ---- correlation ----
    def corr = (message.getHeaders().get('X-Correlation-ID') ?: UUID.randomUUID().toString()) as String
    message.setHeader('X-Correlation-ID', corr)
    message.setProperty('cpc.correlationId', corr)

    // ---- parse ----
    def bodyStr = message.getBody(String) ?: ''
    def payload
    try { payload = new JsonSlurper().parseText(bodyStr) }
    catch (Exception e) { fail('SCHEMA_INVALID', 'The request could not be read. Please try again.', 400) }
    if (!(payload instanceof Map)) fail('SCHEMA_INVALID', 'The request could not be read. Please try again.', 400)

    // ---- identity guard (spec 4.2): verified headers OVERRIDE payload ----
    def vUser   = message.getHeaders().get('X-Verified-User')   as String
    def vRole   = message.getHeaders().get('X-Verified-Role')   as String
    def vClient = message.getHeaders().get('X-Verified-Client') as String
    if (!vUser || !vRole) fail('UNAUTHENTICATED', 'Your session could not be verified. Please sign in again.', 401)
    def role = vRole.equalsIgnoreCase('CSR') ? 'CSR' : 'CUSTOMER'
    payload.changedBy     = vUser
    payload.changedByRole = role
    payload.source        = (role == 'CSR') ? 'CSR' : 'PORTAL'
    payload.onBehalfOf    = (role == 'CSR') ? payload.businessPartner : null
    if (role != 'CSR') payload.caseId = null
    // CUSTOMER may only address their own partner: APIM injects X-Verified-Partner
    def vPartner = message.getHeaders().get('X-Verified-Partner') as String
    if (role == 'CUSTOMER') {
        if (!vPartner) fail('UNAUTHENTICATED', 'Your session could not be verified. Please sign in again.', 401)
        if (pad10(vPartner) != pad10(payload.businessPartner as String))
            fail('FOREIGN_PARTNER', 'You are not authorized for this account.', 403)
    }

    // ---- header-level checks ----
    def reqId = payload.requestId as String
    if (!reqId || !(reqId ==~ /(?i)^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/))
        fail('SCHEMA_INVALID', 'The request could not be read. Please try again.', 400, [[field:'requestId', issue:'missing or not a UUID']])
    message.setProperty('cpc.requestId', reqId)
    if (!payload.businessPartner) fail('SCHEMA_INVALID', 'The request could not be read. Please try again.', 400, [[field:'businessPartner', issue:'missing']])
    payload.businessPartner = pad10(payload.businessPartner as String)
    if (payload.contractAccount) payload.contractAccount = pad12(payload.contractAccount as String)

    // ---- changes[] ----
    def changes = payload.changes
    if (!(changes instanceof List) || changes.isEmpty())
        fail('SCHEMA_INVALID', 'The request could not be read. Please try again.', 400, [[field:'changes', issue:'missing or empty']])
    int maxChanges = ((message.getProperty('CPC_MAX_CHANGES') ?: '50') as String).toInteger()
    if (changes.size() > maxChanges)
        fail('TOO_MANY_CHANGES', 'Too many changes in one request. Please save in smaller batches.', 400)

    def OPS = ['SET','REPLACE','END'] as Set
    def SCOPES = ['BP','CA'] as Set
    def CHANNELS = ['EMAIL','SMS','VOICE','PUSH','POST','ALL'] as Set
    def VALUES = ['IN','OUT'] as Set
    def REASONS = ['CUSTOMER_REQUEST','CSR_CORRECTION','COMPLIANCE'] as Set
    def details = []
    changes.eachWithIndex { ch, i ->
        def add = { issue -> details << [index:i, errorCode:'SCHEMA_INVALID', message:issue] }
        def op = (ch.operation ?: '') as String
        if (!OPS.contains(op)) { details << [index:i, errorCode:'INVALID_OPERATION', message:'operation must be SET, REPLACE or END'] ; return }
        ch.preferenceType = ((ch.preferenceType ?: '') as String).toUpperCase()
        if (!(ch.preferenceType ==~ /^[A-Z0-9_]{1,20}$/)) add('preferenceType invalid')
        def scope = (ch.scope ?: '') as String
        if (!SCOPES.contains(scope)) { details << [index:i, errorCode:'MISSING_SCOPE', message:'scope must be BP or CA'] ; return }
        // rule R1: BP => no contract account; CA => mandatory
        if (scope == 'BP' && ch.contractAccount)
            details << [index:i, errorCode:'SCOPE_CA_MISMATCH', message:'BP-level preference must not carry a contract account']
        if (scope == 'CA') {
            if (!ch.contractAccount) details << [index:i, errorCode:'SCOPE_CA_MISMATCH', message:'CA-level preference requires a contract account']
            else ch.contractAccount = pad12(ch.contractAccount as String)
        }
        ch.channel = ((ch.channel ?: '') as String).toUpperCase()
        if (!CHANNELS.contains(ch.channel)) add('channel invalid')
        if (op != 'END') {
            if (!VALUES.contains((ch.value ?: '') as String)) add('value must be IN or OUT')
            def vf = (ch.validFromNew ?: '') as String
            if (!(vf ==~ /^\d{4}-\d{2}-\d{2}$/)) details << [index:i, errorCode:'INVALID_VALID_FROM', message:'validFromNew must be yyyy-MM-dd']
            else {
                def d = Date.parse('yyyy-MM-dd', vf); def now = new Date()
                if (d.before(now - 30) || d.after(now + 365))
                    details << [index:i, errorCode:'INVALID_VALID_FROM', message:'validFromNew outside allowed window']
            }
        }
        if ((op == 'REPLACE' || op == 'END') && !ch.endedRecordId) add('endedRecordId required for ' + op)
        if (!ch.reasonCode) ch.reasonCode = 'CUSTOMER_REQUEST'
        else if (!REASONS.contains(ch.reasonCode as String)) add('reasonCode not allowed')
    }
    if (!details.isEmpty())
        fail(details[0].errorCode as String, "We couldn't save your preferences. Please refresh and try again.", 400, details)

    // ---- duplicate detection (spec 4.1) — Data Store CPC_SAVE_REQ, best effort ----
    if (((message.getProperty('CPC_DEDUP_ENABLED') ?: 'true') as String) == 'true') {
        try {
            def service = com.sap.it.api.ITApiFactory.getService(com.sap.it.api.asdk.datastore.DataStoreService.class, null)
            if (service != null) {
                def stored = service.get('CPC_SAVE_REQ', reqId)
                if (stored != null) {
                    // Replay the stored response instead of double-writing (idempotency).
                    message.setProperty('cpc.errorCode', 'DUPLICATE_REPLAY')
                    message.setProperty('cpc.httpCode', '200')
                    message.setProperty('cpc.replayBody', new String(stored.getDataAsArray(), 'UTF-8'))
                    throw new IllegalStateException('CPC:DUPLICATE_REPLAY')
                }
            }
        } catch (IllegalStateException e) { throw e }
          catch (Exception ignore) { /* data store unavailable -> proceed without dedup */ }
    }

    // ---- outbound ----
    message.setBody(JsonOutput.toJson(payload))
    message.setHeader('Content-Type', 'application/json')
    message.setHeader('Accept', 'application/json')
    return message
}

static String pad10(String v) { def s = (v ?: '').trim().replaceAll(/\D/, ''); s.padLeft(10, '0') }
static String pad12(String v) { def s = (v ?: '').trim().replaceAll(/\D/, ''); s.padLeft(12, '0') }
