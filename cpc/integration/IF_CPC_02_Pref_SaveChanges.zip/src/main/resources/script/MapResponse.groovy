/* MapResponse.groovy — IF_CPC_02 step H (spec section 6)
 * Passes the S/4 result through (camelCase contract is produced by the RAP action),
 * guarantees response headers, and stores the response in the Data Store for
 * idempotent replay (24 h TTL) — best effort.
 */
import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def body = message.getBody(String) ?: '{"status":"success"}'
    message.setHeader('Content-Type', 'application/json')
    def corr = message.getProperty('cpc.correlationId') as String
    if (corr) message.setHeader('X-Correlation-ID', corr)
    message.setHeader('CamelHttpResponseCode', '200')

    def reqId = message.getProperty('cpc.requestId') as String
    if (reqId) {
        try {
            def service = com.sap.it.api.ITApiFactory.getService(com.sap.it.api.asdk.datastore.DataStoreService.class, null)
            if (service != null) {
                def dBean = new com.sap.it.api.asdk.datastore.DataBean()
                dBean.setDataAsArray(body.getBytes('UTF-8'))
                def dConfig = new com.sap.it.api.asdk.datastore.DataConfig()
                dConfig.setStoreName('CPC_SAVE_REQ')
                dConfig.setId(reqId)
                dConfig.setOverwrite(true)
                dConfig.setExpires(1L)            // days
                service.put(dBean, dConfig)
            }
        } catch (Exception ignore) { /* replay store is best effort */ }
    }
    message.setBody(body)
    return message
}
