/* V7_AfterProvider.groovy — records provider outcome (send path only; the suppress
 * path arrives here with the audit body already built) and ensures the logDispatch
 * payload. Spec section 6. */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*

def Message processData(Message message) {
    if ((message.getProperty('cpc_send') as String) == 'true') {
        def rc = (message.getHeaders().get('CamelHttpResponseCode') ?: '0') as String
        def sent = rc.startsWith('2')
        message.setProperty('cpc_provider_rc', rc)
        message.setProperty('cpc_outcome', sent ? 'SENT' : 'FAILED')
        message.setBody(JsonOutput.toJson([
            action: sent ? 'COMM_SENT' : 'COMM_FAILED',
            msgType: message.getProperty('cpc_msgType'),
            channel: message.getProperty('cpc_channel'),
            reason: sent ? (message.getProperty('cpc_reason') ?: 'OK') : ('PROVIDER_HTTP_' + rc),
            preferenceUUID: message.getProperty('cpc_prefUUID') ?: null,
            eventId: message.getProperty('cpc_evtId'),
            correlationId: message.getProperty('cpc.correlationId')]))
    } else {
        message.setProperty('cpc_outcome', 'SUPPRESSED')
    }
    message.setHeader('Content-Type','application/json')
    return message
}
