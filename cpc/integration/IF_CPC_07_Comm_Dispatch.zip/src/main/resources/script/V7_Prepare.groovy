/* V7_Prepare.groovy — IF_CPC_07: envelope validation, VM-10 event map, dedup, TTL,
 * resolveComm request prep. Spec sections 3-4. */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*

def Message processData(Message message) {
    def fail = { code, http, body=null ->
        message.setProperty('cpc.errorCode', code); message.setProperty('cpc.httpCode', String.valueOf(http))
        if (body) message.setProperty('cpc.replayBody', JsonOutput.toJson(body))
        throw new IllegalStateException('CPC:' + code) }

    def evt
    try { evt = new JsonSlurper().parseText(message.getBody(String) ?: '') }
    catch (Exception e) { fail('COMM_BAD_EVENT', 400) }
    if (!(evt instanceof Map) || !(evt.data instanceof Map)) fail('COMM_BAD_EVENT', 400)
    def d = evt.data
    if (!d.businessPartner) fail('COMM_BAD_EVENT', 400)

    // VM-10: event type -> msgType / class / template (spec section 3)
    def VM10 = [
        'billing.BillCreated.v1'      :['BILL_READY' ,'routine'      ,'TPL_BILL_READY'],
        'fica.PaymentReceived.v1'     :['PAY_CONFIRM','routine'      ,'TPL_PAY_CONFIRM'],
        'fica.PaymentDueReminder.v1'  :['PAY_REMIND' ,'routine'      ,'TPL_PAY_REMIND'],
        'fica.PastDueNotice.v1'       :['PAST_DUE'   ,'regulatory'   ,'TPL_PAST_DUE'],
        'oms.OutageDetected.v1'       :['OUT_DETECT' ,'safety'       ,'TPL_OUT_DETECT'],
        'oms.RestorationEstimate.v1'  :['OUT_ETR'    ,'safety'       ,'TPL_OUT_ETR'],
        'oms.PowerRestored.v1'        :['OUT_RESTORE','safety'       ,'TPL_OUT_RESTORE'],
        'oms.PlannedOutage.v1'        :['OUT_PLANNED','routine'      ,'TPL_OUT_PLANNED'],
        'drms.EventDispatch.v1'       :['DR_EVENT'   ,'time-critical','TPL_DR_EVENT'],
        'usage.HighUsage.v1'          :['HIGH_USAGE' ,'routine'      ,'TPL_HIGH_USAGE'],
        'usage.ProjectedBill.v1'      :['BILL_PROJ'  ,'routine'      ,'TPL_BILL_PROJ'],
    ]
    def key = (evt.type as String).replaceFirst(/^zcpc\./,'')
    def m = VM10[key]
    if (m == null) fail('COMM_UNKNOWN_EVENT', 200, [status:'parked', code:'COMM_UNKNOWN_EVENT', type:evt.type])
    message.setProperty('cpc_msgType', m[0]); message.setProperty('cpc_class', m[1]); message.setProperty('cpc_template', m[2])

    def corr = (message.getHeaders().get('X-Correlation-ID') ?: UUID.randomUUID().toString()) as String
    message.setHeader('X-Correlation-ID', corr); message.setProperty('cpc.correlationId', corr)
    def evtId = (evt.id ?: UUID.randomUUID().toString()) as String
    message.setProperty('cpc_evtId', evtId)
    message.setProperty('cpc_event', JsonOutput.toJson(d))

    // dedup (successful dispatches only - marked in V7_Respond)
    try {
        def ds = com.sap.it.api.ITApiFactory.getService(com.sap.it.api.asdk.datastore.DataStoreService.class, null)
        if (ds != null && ds.get('CPC_COMM_EVT', evtId) != null)
            fail('DUPLICATE_OK', 200, [status:'duplicate', eventId:evtId])
    } catch (IllegalStateException e) { throw e } catch (Exception ignore) {}

    // TTL per class (spec section 7): expired => suppress (still audited downstream)
    def ttlH = ['safety':2, 'time-critical':1, 'routine':24, 'regulatory':Integer.MAX_VALUE][m[1]]
    try {
        def ts = evt.time ? Date.parse("yyyy-MM-dd'T'HH:mm:ss'Z'", (evt.time as String).replaceAll(/\..*Z$/,'Z')) : new Date()
        if (ttlH != Integer.MAX_VALUE && ts.before(new Date(System.currentTimeMillis() - ttlH*3600L*1000L))) {
            message.setProperty('cpc_send','false'); message.setProperty('cpc_reason','EXPIRED')
        }
    } catch (Exception ignore) {}

    // resolveComm request (spec section 4) — decision fetched at SEND TIME (R0)
    message.setBody(JsonOutput.toJson([PARTNER: d.businessPartner, VKONT: d.contractAccount ?: null,
        MSG_TYPE: m[0], EVENT_ID: evtId, EVENT_TS: evt.time ?: '']))
    message.setHeader('Content-Type','application/json')
    return message
}
