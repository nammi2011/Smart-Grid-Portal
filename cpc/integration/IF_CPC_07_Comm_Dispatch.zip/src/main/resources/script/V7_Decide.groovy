/* V7_Decide.groovy — after resolveComm: fail-closed, quiet hours, provider payload.
 * Spec sections 4-5, 7-8. */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*

def Message processData(Message message) {
    def fail = { code, http, body=null ->
        message.setProperty('cpc.errorCode', code); message.setProperty('cpc.httpCode', String.valueOf(http))
        if (body) message.setProperty('cpc.replayBody', JsonOutput.toJson(body))
        throw new IllegalStateException('CPC:' + code) }

    if ((message.getProperty('cpc_send') as String) == 'false') { // pre-decided (EXPIRED)
        message.setProperty('cpc_channel',''); return prepAudit(message) }

    def rc = (message.getHeaders().get('CamelHttpResponseCode') ?: '0') as String
    if (!rc.startsWith('2')) {
        // FAIL CLOSED: never send without a fresh decision; 503 lets the webhook redeliver
        fail('RESOLVE_UNAVAILABLE', 503)
    }
    def r
    try { r = new JsonSlurper().parseText(message.getBody(String) ?: '') } catch (Exception e) { fail('RESOLVE_UNAVAILABLE', 503) }
    def send = (r.SEND == 'X' || r.SEND == true || r.send == true)
    message.setProperty('cpc_reason', (r.REASON ?: r.reason ?: (send ? 'OK' : 'OPTED_OUT')) as String)
    message.setProperty('cpc_prefUUID', (r.PREF_UUID ?: r.prefUUID ?: '') as String)
    def channel = (r.CHANNEL ?: r.channel ?: '') as String
    message.setProperty('cpc_channel', channel)

    if (send) {
        // quiet hours for routine voice/SMS (spec 7); safety/regulatory exempt
        def cls = message.getProperty('cpc_class') as String
        if (cls == 'routine' && (channel == 'VOICE' || channel == 'SMS')) {
            int h = new Date().getHours()
            int qs = ((message.getProperty('QUIET_START_HOUR') ?: '21') as String).toInteger()
            int qe = ((message.getProperty('QUIET_END_HOUR') ?: '8') as String).toInteger()
            boolean quiet = (qs > qe) ? (h >= qs || h < qe) : (h >= qs && h < qe)
            if (quiet) fail('QUIET_DEFERRED', 503)   // webhook redelivers; re-resolved on release (R0)
        }
        def d = new JsonSlurper().parseText(message.getProperty('cpc_event') as String)
        def vars = [:]; d.each { k, v -> if (!(k in ['businessPartner','contractAccount'])) vars[k] = v }
        message.setBody(JsonOutput.toJson([channel: channel, to: (r.ADDRESS ?: r.address ?: ''),
            templateId: (message.getProperty('cpc_template') as String) + '_' + channel,
            variables: vars, clientRef: (message.getProperty('cpc_evtId') as String) + ':' + channel,
            priority: cls]))
        message.setHeader('Content-Type','application/json')
        message.setProperty('cpc_send','true')
        return message
    }
    message.setProperty('cpc_send','false')
    return prepAudit(message)
}

def Message prepAudit(Message message) {
    // suppress path goes straight to the audit RR — build logDispatch body now
    message.setBody(groovy.json.JsonOutput.toJson([
        action: 'COMM_SUPPRESSED',
        msgType: message.getProperty('cpc_msgType'),
        channel: message.getProperty('cpc_channel') ?: '',
        reason: message.getProperty('cpc_reason'),
        preferenceUUID: message.getProperty('cpc_prefUUID') ?: null,
        eventId: message.getProperty('cpc_evtId'),
        correlationId: message.getProperty('cpc.correlationId')]))
    message.setHeader('Content-Type','application/json')
    return message
}
