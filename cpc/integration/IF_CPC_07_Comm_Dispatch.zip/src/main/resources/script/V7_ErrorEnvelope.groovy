/* V7_ErrorEnvelope.groovy — DUPLICATE_OK / COMM_UNKNOWN_EVENT => 200 (no retry);
 * RESOLVE_UNAVAILABLE / QUIET_DEFERRED => 503 + Retry-After (webhook redelivers,
 * decision re-resolved on the next attempt per R0); unexpected => 500. */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) {
    def code = (message.getProperty('cpc.errorCode') ?: 'INTERNAL') as String
    def http = (message.getProperty('cpc.httpCode') ?: '500') as String
    def replay = message.getProperty('cpc.replayBody') as String
    def corr = (message.getProperty('cpc.correlationId') ?: '') as String
    message.setHeader('Content-Type','application/json')
    message.setHeader('X-Correlation-ID', corr)
    message.setHeader('CamelHttpResponseCode', http)
    if (replay) { message.setBody(replay); return message }
    message.setBody(JsonOutput.toJson([error:[code:code, correlationId:corr, retryable: http.startsWith('5')]]))
    if (http.startsWith('5')) message.setHeader('Retry-After', code == 'QUIET_DEFERRED' ? '3600' : '120')
    return message
}
