/* V7_Respond.groovy — after the audit RR. SENT/SUPPRESSED + audit ok => dedup mark
 * + 200. Provider FAILED => 500 (redelivery; resolve re-runs per R0). Audit write
 * failure => 500 (no completion without evidence). Spec sections 6, 8. */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) {
    def logRc = (message.getHeaders().get('CamelHttpResponseCode') ?: '0') as String
    def outcome = (message.getProperty('cpc_outcome') ?: 'SUPPRESSED') as String
    def evtId = message.getProperty('cpc_evtId') as String
    def ok = logRc.startsWith('2') && outcome != 'FAILED'

    if (ok) {
        try {
            def ds = com.sap.it.api.ITApiFactory.getService(com.sap.it.api.asdk.datastore.DataStoreService.class, null)
            if (ds != null) {
                def b = new com.sap.it.api.asdk.datastore.DataBean(); b.setDataAsArray('done'.getBytes('UTF-8'))
                def c = new com.sap.it.api.asdk.datastore.DataConfig(); c.setStoreName('CPC_COMM_EVT'); c.setId(evtId)
                c.setOverwrite(true); c.setExpires(2L); ds.put(b, c)
            }
        } catch (Exception ignore) {}
    }
    message.setBody(JsonOutput.toJson([status: ok ? 'done' : 'retry', outcome: outcome,
        channel: message.getProperty('cpc_channel') ?: '', reason: message.getProperty('cpc_reason') ?: '',
        auditWriteBack: logRc, eventId: evtId]))
    message.setHeader('Content-Type','application/json')
    message.setHeader('X-Correlation-ID', message.getProperty('cpc.correlationId') ?: '')
    message.setHeader('CamelHttpResponseCode', ok ? '200' : '500')
    if (!ok) message.setHeader('Retry-After', '120')
    return message
}
